package com.ybj.mydagger2demo.main;

import android.util.Log;

/**
 * Created by 杨阳洋 on 2017/12/31.
 */

public class TestBeanTwo {

    public TestBeanTwo() {
    }

    public void register(){
        Log.e("TAG", "TestBeanTwo register()");
    }

}
