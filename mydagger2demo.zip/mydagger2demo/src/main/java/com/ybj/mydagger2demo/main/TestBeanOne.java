package com.ybj.mydagger2demo.main;

import android.util.Log;

/**
 * Created by 杨阳洋 on 2017/12/31.
 */

public class TestBeanOne {

    public TestBeanOne() {
    }

    public void register(){
        Log.e("TAG", "TestBeanOne register()");
    }

}
